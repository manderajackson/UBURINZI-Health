# Uburinzi Health — complete build & launch guide

The single document that takes you from zero to a working, deployed, installable Uburinzi Health.
Every number in it was measured on your own account, not estimated. Detailed topics live in the
linked docs; this page is the spine.

**Status: 17 September 2026 — live on Africa's Talking, deployed to `uburinzi.vercel.app`, awaiting
the Postgres connection.**

> **Going live?** [WHAT-YOU-NEED-TO-DO.md](WHAT-YOU-NEED-TO-DO.md) is the 15-minute checklist of
> account steps (GitHub token, Vercel Root Directory, Neon, env vars, redeploy). This document
> explains the system behind them.

---

## 1. What Uburinzi Health is

A clinical follow-up platform for chronic patients **between** clinic visits. A patient with
diabetes, hypertension, HIV, TB, asthma, epilepsy, heart failure or an antenatal pregnancy gets an
ordinary SMS on the day their medication is due, answers `1 = yes, I took it`, `2 = no`,
`3 = I'm not well`, and the clinic sees who is slipping **before** the next appointment instead of
after it.

The design constraint that drives everything: **the patient installs nothing and needs no data.** A
2G feature phone on MTN or Airtel Rwanda is enough. WhatsApp and voice are escalations for people who
have them, never a requirement.

---

## 2. Where things stand right now

| Item | State |
|---|---|
| **Africa's Talking app** | **LIVE** — app name `UBURINZI`, username `Uburinzi`, sandbox off |
| **Wallet** | **RWF 91.74** (≈ 8 SMS) — top up before the pilot |
| **SMS** | 🟢 **live driver**, 4 real messages accepted by AT with message IDs |
| **Measured price** | **10–12 RWF per SMS** (12 to one network, 10 to the other — priced per operator) |
| **WhatsApp** | ⏸ simulator — AT sandbox has no WhatsApp; needs a live provisioned number |
| **Voice** | ⏸ unavailable in Rwanda — AT lists only **SMS (Bulk & Short Code) + USSD** here; escalations become clinic callback tasks |
| **USSD** | 🟢 built (`/api/webhooks/ussd`), switched **off** until AT issues a real code |
| **Sender ID** | not yet requested — messages currently arrive as `AFRICASTKNG` |
| **Deployment** | `https://uburinzi.vercel.app` — **serve code is stale and login returns 500** (no `DATABASE_URL`) |
| **Patients** | 53 demo patients, 45 days of synthetic history |
| **Tests** | 53 passing |

---

## 3. How the system works

```
Scheduled check-in (per programme cadence)
        │
        ▼
SMS out ────────► patient replies 1 / 2 / 3   (or dials a USSD code where SMS can't be answered)
        │                    │
        │                    ▼
        │            reply parsed → adherence, missed-dose streak, no-reply streak
        │                    │
        │                    ▼
        │            risk rules → green / amber / red → alert queue for the nurse
        │
        └── no reply? ──► 24 h: WhatsApp retry ──► 48 h: voice call
                                                     └─ no voice in Rwanda → RED "phone this
                                                        patient" task on the nurse queue
```

Safety rails: sending only 08:00–18:00 clinic-local time, a hard daily spend cap that even a manual
"run now" cannot bypass, per-patient weekly call limits, one consent flag per patient, and `STOP`
handled in every language.

**Programmes:** diabetes, hypertension, HIV, TB, asthma, epilepsy, heart failure, ANC.
**Languages:** Kinyarwanda, English, French, Swahili — templates are database rows, editable in
**Protocols** without touching code.

---

## 4. Accounts

| Email | Password | Role | Name |
|---|---|---|---|
| `manderajackson99@gmail.com` | `uburinzi2026` | admin | Mandera Jackson |
| `yahshuamediasite@gmail.com` | `uburinzi2026` | clinician | UWASE Aline |

Change both passwords on the deployed site (**Settings → Users**). On Vercel the login page never
pre-fills the password: `DEMO_MODE` switches itself off when the `VERCEL` env var is present.

---

## 5. Run it locally (60 seconds)

```bash
cd ~/uburinzi
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.cli reset          # 53 patients, 45 days of history
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Open `http://localhost:8000`. Locally this uses **SQLite and a background worker thread**, and SMS
goes to the simulator (no airtime).

---

## 6. Africa's Talking — already connected, here's how to redo it

```bash
# paste the key into AFRICASTALKING_API_KEY= in .env, then:
python -m app.cli use-live --from-env --test-to 0784852344
python -m app.cli channels            # balance, drivers, webhook URLs
```

That command writes `.env` (git-ignored, never zipped), stores the key **encrypted** in the database,
flips the SMS driver live, checks the balance and prints your webhook URLs.

Gotchas, all hit and solved:
* A brand-new key is rejected for ~3 minutes.
* A sandbox key needs `--sandbox`; a live key must use the live app username.
* AT throttles bursts and answers with a fake *"authentication is invalid"* — sends and balance
  checks retry automatically.

**Regenerating a key changes nothing** except the credential: patients, history, protocols and
alerts live in our database. It is also good hygiene if a key is ever pasted somewhere public.

---

## 7. The two Rwanda rules that shaped the design

1. **Rwanda cannot receive replies to an A2P SMS.** MTN Rwanda and Airtel Rwanda do not support it —
   carrier-level, not an Africa's Talking quirk. Your own handset confirms it: the test message showed
   *"user isn't available"*. So `1 = Yes` by SMS reply is a dead end here.
2. **AT publishes no Voice product for Rwanda** — only SMS (Bulk & Short Code) and USSD.

What we built for this:

* **USSD reply channel** — `/api/webhooks/ussd`, menus in Kinyarwanda/English/French/Swahili,
  answers recorded into the same tracker, `3` raising a RED alert, and **no acknowledgement SMS** (the
  closing screen is the confirmation, so one check-in costs one session, not two).
* **Check-ins rewrite themselves** — with USSD selected, the impossible *"Subiza: 1=Yego, 2=Oya…"*
  tail is replaced by the dial instruction, kept inside one 160-character segment.
* **Voice degrades gracefully** — when no voice channel exists, the 48-hour rung of the ladder raises
  a red *"please phone this patient"* task instead of failing silently.

**Switch it on** when AT gives you a code: **Channels → How patients answer → USSD**, paste the code.
It is currently left on `sms` so no patient ever sees a dial string we don't own.

---

## 8. Deploy to Vercel — the exact sequence, including the two mistakes to avoid

The repo is already adapted: `vercel.json` (Python runtime, routes, cron), `api/index.py` (ASGI
entry), `/api/cron/scheduler` (Vercel Cron replaces the background thread, which cannot survive
serverless).

**Mistake #1 — no Postgres.** A SQLite file cannot survive on a serverless filesystem. Without
`DATABASE_URL`, `GET /login` renders fine but **`POST /login` returns 500** — exactly what your
deployment does now.

**Mistake #2 — setting env vars after the deploy.** Vercel only applies them to *new* deployments.
Always **Redeploy** after changing them.

```bash
# one command — clones your repo, overlays the current files, commits, pushes
cd ~/uburinzi
python -m app.cli push --repo https://github.com/YOUR-USER/uburinzi-health.git
```

It updates the branch that's already there rather than creating a second one, so a Vercel project
already connected to the repo stays connected and builds the push automatically. Add `--clean` if an
earlier zip upload left a nested `uburinzi/` folder behind, `--dry-run` to preview. Private repo:
embed a personal-access token — `https://ghp_xxxx@github.com/YOUR-USER/uburinzi-health.git`.

Equivalent by hand, if you prefer to run git yourself:

```bash
cd ~/uburinzi && python -m app.cli bundle      # refresh ~/github-upload
cd ~/github-upload
git remote add origin git@github.com:YOUR-USER/uburinzi-health.git
git push -u origin main
```

Then, in **Vercel → Settings → Environment Variables**:

| Variable | Value |
|---|---|
| `UBURINZI_DATABASE_URL` | paste Neon's string as-is — see the note below ← **required** |
| `UBURINZI_SECRET_KEY` | long random string (encrypts stored provider credentials) |
| `CRON_SECRET` | random string (locks `/api/cron/scheduler`) — **no `UBURINZI_` prefix** |
| `AFRICASTALKING_USERNAME` | `Uburinzi` |
| `AFRICASTALKING_API_KEY` | your `atsk_…` |
| `AFRICASTALKING_SANDBOX` | `false` |
| `UBURINZI_SMS_SENDER_ID` | `UBURINZI` once approved (leave empty until then) |
| `UBURINZI_PUBLIC_BASE_URL` | `https://uburinzi.vercel.app` |
| `UBURINZI_DAILY_SMS_CAP` | `200` |
| `UBURINZI_PLAY_SHA256` | Play signing fingerprint (see §10) |

> **Paste Neon's connection string exactly as they give it.** The app rewrites
> `postgres://…` into the `postgresql+psycopg://…` form its driver needs and adds `sslmode=require`
> if it's missing, so you don't have to edit anything. It also accepts the unprefixed `DATABASE_URL`
> and `SECRET_KEY` names, in case you connect Neon through Vercel's own integration.

**→ Deployments → ⋮ → Redeploy.** Neon ([neon.tech](https://neon.tech)) is free and needs no card.

---

## 9. Verify it works

```bash
curl https://uburinzi.vercel.app/health
```

`/health` now reports everything that can break a deploy:

```json
{ "ok": true, "serverless": true,
  "database": { "dialect": "postgresql", "reachable": true },
  "channels": { "sms": "africastalking", "whatsapp": "simulator", "voice": "simulator", "reply": "sms" },
  "at_username": "Uburinzi" }
```

| Check | Pass looks like |
|---|---|
| Database | `dialect: postgresql`, `reachable: true`, **no `warning`** |
| Login | `/login` shows `manderajackson99@gmail.com`, blank password field, no demo banner |
| Sign in | POST returns 303 → dashboard 200 (no more 500) |
| Balance | `/api/channels/balance` → `RWF 91.7351` |
| Cron | `curl -H "Authorization: Bearer $CRON_SECRET" …/api/cron/scheduler` → `ok` |
| SMS | Send a test from **Channels** → it physically arrives |
| Asset links | `/.well-known/assetlinks.json` → JSON (needed for Play) |
| Offline | Install on a phone, cut the connection, `/alerts` still loads |

---

## 10. Publish on Google Play (optional, later)

The dashboard is a PWA; Play accepts PWAs via a **Trusted Web Activity** — a native shell that opens
your site full-screen with no browser bar. Patients still install nothing.

```bash
npm i -g @bubblewrap/cli
cd ~/uburinzi
bubblewrap init --manifest ./twa-manifest.json    # package rw.uburinzi.health
bubblewrap build                                  # → app-release-bundle.aab
```

1. `keytool -list -v -keystore ./android.keystore -alias android` → copy **SHA-256**.
2. Paste it into **Channels → Play Store** (or `UBURINZI_PLAY_SHA256`); `/.well-known/assetlinks.json`
   then serves it automatically. Add Google's app-signing fingerprint too once enrolled.
3. Play Console needs a **$25 one-off** account, the privacy policy at `/privacy`, the 1080×1920
   screenshots in `docs/store/`, and the data-safety form.

Full walkthrough, including store-listing copy: **[play-store.md](play-store.md)**.

---

## 11. Real patients

1. **Settings → set the clinic** name, district, phone, timezone.
2. **Import patients (CSV)** — `python -m app.cli export-sample` gives the template; import with
   **consent off**, so nothing is sent automatically.
3. **Consent per patient** — record it, then switching on enrolment starts their messages.
4. **Start with 20–30 patients**, review the alert queue daily for two weeks, then expand.

Consent, opt-out (`STOP` in English and Kinyarwanda, honoured within 24 h), sending hours and data
minimisation are enforced in the app; Rwanda-specific detail in
**[launch-checklist.md](launch-checklist.md)**.

---

## 12. Command reference

```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000   # run
python -m app.cli seed | reset | stats                      # demo data / impact report
python -m app.cli send-due | daily-jobs | run-scheduler     # drive the engine by hand
python -m app.cli import-csv data/clinic.csv                # real patients
python -m app.cli use-live --from-env --test-to 0784852344  # go live on AT
python -m app.cli channels                                  # balance + webhook URLs
python -m app.cli bundle                                    # refresh /home/user/github-upload + zips
python -m pytest tests -q                                   # 53 tests
```

Webhooks (all relative to your domain): `/api/webhooks/sms/inbound`, `/api/webhooks/sms/delivery`,
`/api/webhooks/ussd`, `/api/webhooks/whatsapp`, `/api/webhooks/voice/answer`,
`/api/webhooks/voice/dtmf`, `/api/webhooks/voice/event`, plus `/api/cron/scheduler`.

---

## 13. Costs (measured, not estimated)

| Volume | Monthly cost |
|---|---|
| 1 patient | ~205 RWF |
| 20 patients | ~4,100 RWF (~$3) |
| 52 patients | ~10,600 RWF (~$8) |

Infrastructure: Vercel Hobby free (Pro ~$20/mo for commercial use), Neon free tier covers the pilot.
Voice, where available, is ~60 RWF/minute; WhatsApp ~12 RWF per conversation.

---

## 14. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `POST /login` → 500 on Vercel | no `DATABASE_URL` (SQLite can't write) | add Postgres URL, **redeploy** |
| Login 401 "authentication is invalid" | key <3 min old, wrong username/key pairing, or AT throttling | wait 3 min; sandbox key needs `sandbox`; retry |
| Balance call fails right after a send | AT rate-limit | automatic retry (4 s, then 8 s) |
| Messages send but phones never receive | sandbox app (billed, never delivered) | switch to the live app |
| Voice fails | AT has no Voice in Rwanda | expected — ladder creates a callback task |
| No replies ever arrive | Rwanda can't reply to A2P SMS | switch the reply path to USSD/short code |
| Env var change had no effect | Vercel applies them only to new deploys | Redeploy |
| `/download` errors on Vercel | read-only filesystem | handled: falls back to `/tmp` |

---

## 15. Build log (what was done, in order)

1. **Core platform** — domain model, protocol engine, Kinyarwanda/English/French/Swahili templates,
   reply parsing, rule-based alerts, clinic dashboard, 52-patient demo cohort, CSV import/export,
   30-day impact report, PWA (installable, offline).
2. **Live channels** — Africa's Talking SMS wired and **proven with real sends**; WhatsApp and voice
   drivers built; AT's SDK contracts verified against source.
3. **Live account** — created the `UBURINZI` app (username `Uburinzi`), went live, measured the real
   price at 10–12 RWF/SMS, and corrected the cost model (it had been a 27 RWF estimate).
4. **Rwanda reply path** — discovered the two-way A2P and Voice restrictions, then built the USSD
   channel, self-rewriting check-in messages, and graceful voice degradation.
5. **Deploy + store** — Vercel adaptation (Postgres, cron, serverless detection, read-only-safe zip),
   Play Store TWA package, Digital Asset Links, privacy policy, store screenshots.
6. **Identity** — accounts renamed to Mandera Jackson and UWASE Aline, Kigali removed from all
   product copy (the platform is country-neutral), accelerator branding purged, and a
   `python -m app.cli bundle` workflow that regenerates and commits the GitHub-ready folder after
   every change.

**Five production bugs found and fixed along the way:** drivers receiving the encrypted key blob;
`/channels/test` crashing on a second test number; voice dedupe keys colliding on a patient's second
weekly call; `force` bypassing the daily spend cap; and AT's `"RWF 12.0000"` cost string being
mis-parsed so every message logged the old estimate.
