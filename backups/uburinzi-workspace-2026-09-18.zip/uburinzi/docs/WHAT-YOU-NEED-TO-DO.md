# What you need to do — the whole list

Everything in the code is finished and tested. What's left is **account work on websites I can't log
into on your behalf**: five steps, about 15 minutes, in this order.

Two of the five are "do this, then paste the result back to me" — I'll do the rest.

---

## Step 1 — Give me permission to push to GitHub · 2 min

I have your repo read-only. To push, I need a token.

1. Open **<https://github.com/settings/tokens>**
2. **Generate new token → Generate new token (classic)**
3. Note: `Uburinzi push` · Expiration: **7 days** · tick **`repo`**
4. **Generate token**, copy the `ghp_…` string
5. **Paste it to me**

I'll push the rebuilt project, then verify the repo myself.

6. When I say it's done: same page → **Delete** the token. It only had to work once.

*Rather do it yourself?* Skip to [Appendix A](#appendix-a--doing-the-push-yourself).

---

## Step 2 — Clear Vercel's Root Directory · 30 sec

Your repo currently holds three nested copies (`uburinzi/`, `workspace-01/`, `workspace-02/`), and
Vercel is building one of the old ones. After my push there will be exactly **one project, at the
repo root**, so Vercel must stop looking inside a subfolder.

1. **<https://vercel.com>** → open your Uburinzi project
2. **Settings → General → Root Directory**
3. **Edit → clear the field completely → Save**

Leave it empty. Empty = repo root.

---

## Step 3 — Create the database · 3 min

The live site returns 500 on sign-in for one reason: Vercel's filesystem is read-only, so SQLite
can't create its file. A hosted Postgres fixes it.

1. **<https://neon.tech>** → sign in with GitHub
2. **New project** → Name: `uburinzi` · Region: **Europe (Frankfurt)** (closest to Rwanda) → **Create**
3. Copy the **connection string**. It looks like:

   ```
   postgresql://neondb_owner:AbCd1234@ep-cool-mud-123456.eu-central-1.aws.neon.tech/neondb?sslmode=require
   ```

4. **Paste it to me** — I'll check the format and tell you the exact line to paste into Vercel.

Free tier, no card, plenty for a pilot.

---

## Step 4 — Set the environment variables · 3 min

**Vercel → your project → Settings → Environment Variables.** Add each one, tick all three
environments (Production / Preview / Development), **Save**.

| Variable | Value |
|---|---|
| `UBURINZI_DATABASE_URL` | the Neon string from Step 3 — **paste it as-is**, the app fixes the format |
| `UBURINZI_SECRET_KEY` | long random string (see below) |
| `CRON_SECRET` | another long random string — **no `UBURINZI_` prefix on this one** |
| `AFRICASTALKING_USERNAME` | `Uburinzi` |
| `AFRICASTALKING_API_KEY` | your `atsk_…` key, from the Africa's Talking dashboard |
| `AFRICASTALKING_SANDBOX` | `false` |
| `UBURINZI_PUBLIC_BASE_URL` | `https://uburinzi.vercel.app` |
| `UBURINZI_DAILY_SMS_CAP` | `200` |
| `UBURINZI_SMS_COST_RWF` | `12` |

To make the two random strings, run this in a terminal (or just ask me and I'll generate them):

```bash
openssl rand -hex 32
```

Run it twice — one value for each variable.

> **Why Step 3's string needs no editing:** the app rewrites `postgres://…` into the
> `postgresql+psycopg://…` form its driver needs and adds `sslmode=require` if it's missing. Paste
> whatever Neon shows you.

---

## Step 5 — Redeploy · 1 min

**Vercel → Deployments → ⋮ (on the newest) → Redeploy.**

Vercel only applies environment variables to *new* deployments — this is the step people skip.
Wait 1–2 minutes.

---

## Step 6 — Check it works · 1 min

Open **<https://uburinzi.vercel.app/health>**. It should look like this:

```json
{"ok":true,"serverless":true,
 "database":{"dialect":"postgresql","reachable":true},
 "channels":{"sms":"africastalking",...},"at_username":"Uburinzi"}
```

| Check | Pass looks like |
|---|---|
| Database | `"dialect":"postgresql"`, `"reachable":true`, **no `"warning"`** |
| Sign in | `manderajackson99@gmail.com` / `uburinzi2026` → dashboard loads (no 500) |
| Balance | **Channels** page shows your RWF balance |
| Real SMS | **Channels → Send test** → it arrives on your phone |

If `/health` still shows `"driver":"simulator"` with no `database` block, Vercel is serving an old
build — check that Step 2 was saved and Step 5 ran.

---

## Step 7 — Secure it · 2 min

Sign in and change both passwords (**Settings → Users**). `uburinzi2026` is the default and is
written into the public repository.

---

## Later, when you're ready

| When | What |
|---|---|
| Before real patients | Register sender ID `UBURINZI` (needs AT approval + carrier pre-registration, ~3 weeks) |
| For replies | Ask AT for a USSD code, then set it in **Channels → How patients answer** |
| Play Store | **[play-store.md](play-store.md)** — needs the Play Console's $25 fee |
| Top-ups | Keep AT credit above ~RWF 5,000; Neon free tier is enough for now |
| Real patients | **Import patients (CSV)** — import with consent **off**, then switch it on per patient |

---

## If something goes wrong

| Symptom | Cause | Fix |
|---|---|---|
| `/health` has no `database` block | Vercel serving a stale build | Redo Step 2, then Step 5 |
| `dialect` is `sqlite` | `UBURINZI_DATABASE_URL` not set (note the prefix) | Step 4, then **redeploy** |
| `"warning"` about Postgres | same as above | same |
| Env var change had no effect | variables only apply to new deployments | Step 5 again |
| Login 500 but `/health` is green | database not migrated yet | tell me — I'll check the tables |
| Build fails: "No module named …" | Root Directory still points into the deleted folders | Step 2 |

---

## Appendix A — doing the push yourself

If you'd rather not share a token, run this on your own computer. Download
`dist/uburinzi-health-github.zip` (or `python -m app.cli bundle` to refresh `~/github-upload`),
unzip it, then:

```bash
git clone https://github.com/manderajackson/UBURINZI-Health.git push
cd push

# copy the new files in (macOS/Linux)
rsync -a --exclude='.git' /path/to/uburinzi-health-github/ .

# drop the three old snapshots
git rm -r -q --ignore-unmatch uburinzi workspace-01 workspace-02 github-upload.md

git add -A
git commit -m "Uburinzi Health — full rebuild, single project at repo root"
git push origin main
```

Git will ask for your GitHub credentials; a personal-access token is the password.

Then continue from **Step 2**.
