"""Postgres URL handling — the difference between a deployment that signs in and one that 500s."""
from __future__ import annotations

import importlib

import pytest

import app.config as config


def _reload():
    """Reload config so it re-reads the environment."""
    return importlib.reload(config)


# --------------------------------------------------------------------------- #
# URL normalisation
# --------------------------------------------------------------------------- #

def test_plain_postgres_url_becomes_psycopg3():
    """Neon hands out postgres:// — SQLAlchemy would map that to psycopg2, which isn't installed."""
    out = config._normalise_db_url("postgres://u:p@ep-x.eu-central-1.aws.neon.tech/neondb")
    assert out.startswith("postgresql+psycopg://")
    assert "sslmode=require" in out


def test_postgresql_url_becomes_psycopg3():
    out = config._normalise_db_url("postgresql://u:p@ep-x/db")
    assert out.startswith("postgresql+psycopg://")


def test_explicit_driver_is_left_alone():
    url = "postgresql+psycopg://u:p@ep-x/db?sslmode=require"
    assert config._normalise_db_url(url).startswith("postgresql+psycopg://u:p@ep-x/db")


def test_existing_sslmode_is_respected():
    out = config._normalise_db_url("postgresql://u:p@ep-x/db?sslmode=disable")
    assert "sslmode=disable" in out
    assert "require" not in out


def test_local_postgres_needs_no_forced_ssl():
    out = config._normalise_db_url("postgresql://u:p@localhost:5432/db")
    assert "sslmode" not in out


def test_sqlite_urls_pass_through_untouched():
    url = "sqlite:////home/user/uburinzi/data/uburinzi.db"
    assert config._normalise_db_url(url) == url


# --------------------------------------------------------------------------- #
# Which variable wins
# --------------------------------------------------------------------------- #

def test_prefixed_variable_wins(monkeypatch):
    monkeypatch.setenv("UBURINZI_DATABASE_URL", "postgresql+psycopg://u:p@h/one")
    monkeypatch.setenv("DATABASE_URL", "postgresql+psycopg://u:p@h/two")
    assert _reload().DATABASE_URL.startswith("postgresql+psycopg://u:p@h/one")


def test_platform_DATABASE_URL_is_used_when_unprefixed_var_is_absent(monkeypatch):
    """Vercel's Neon integration injects DATABASE_URL — it must not be ignored."""
    monkeypatch.delenv("UBURINZI_DATABASE_URL", raising=False)
    monkeypatch.setenv("DATABASE_URL", "postgresql+psycopg://u:p@h/two")
    assert _reload().DATABASE_URL.startswith("postgresql+psycopg://u:p@h/two")


def test_secret_key_prefixed_and_fallback(monkeypatch):
    monkeypatch.setenv("UBURINZI_SECRET_KEY", "abc")
    assert _reload().SECRET_KEY == "abc"
    monkeypatch.delenv("UBURINZI_SECRET_KEY")
    monkeypatch.setenv("SECRET_KEY", "xyz")
    assert _reload().SECRET_KEY == "xyz"


def test_falls_back_to_sqlite_when_nothing_is_set(monkeypatch):
    monkeypatch.delenv("UBURINZI_DATABASE_URL", raising=False)
    monkeypatch.delenv("DATABASE_URL", raising=False)
    assert _reload().DATABASE_URL.startswith("sqlite:")
