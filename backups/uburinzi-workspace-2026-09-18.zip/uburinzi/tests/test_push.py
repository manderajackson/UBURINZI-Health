"""Tests for `python -m app.cli push` — pushing the project to a GitHub repository.

These run entirely against local bare repositories (no network), which is exactly
how Git behaves against a remote: the code under test cannot tell the difference.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from app.package import iter_source_files, push_to_remote


def _bare(tmp_path: Path, name="remote.git"):
    remote = tmp_path / name
    subprocess.run(["git", "init", "--bare", "-q", str(remote)], check=True)
    return remote


def _git(*args, cwd):
    return subprocess.run(
        ["git", "-c", "user.name=t", "-c", "user.email=t@t", *args],
        cwd=str(cwd), capture_output=True, text=True,
    )


def _tree(remote: Path, branch="main"):
    proc = subprocess.run(
        ["git", "--git-dir", str(remote), "ls-tree", "-r", "--name-only", branch],
        capture_output=True, text=True,
    )
    return set(proc.stdout.split())


def _seed_old_repo(remote: Path, workdir: Path):
    """A repo that already holds an older build — the common real-world case."""
    _git("init", "-q", "-b", "main", ".", cwd=workdir)
    (workdir / "templates").mkdir()
    (workdir / "uburinzi").mkdir()
    (workdir / "templates" / "login.html").write_text(
        "<html>founder@uburinzi.rw nurse@uburinzi.rw timbuktoo Kigali MVP</html>\n")
    (workdir / "uburinzi" / "README.md").write_text("stale nested copy from a zip upload\n")
    (workdir / "legacy_notes.txt").write_text("obsolete\n")
    (workdir / "README.md").write_text("old\n")
    _git("add", "-A", cwd=workdir)
    _git("commit", "-qm", "old build", cwd=workdir)
    _git("remote", "add", "origin", str(remote), cwd=workdir)
    _git("push", "-q", "-u", "origin", "main", cwd=workdir)


def test_push_to_empty_repository(tmp_path):
    remote = _bare(tmp_path)
    result = push_to_remote(str(remote), message="first push")

    assert result["ok"], result.get("detail")
    assert result["changed"] >= 50
    tracked = _tree(remote, result["branch"])
    assert "vercel.json" in tracked
    assert "api/index.py" in tracked
    assert "START-HERE.md" in tracked


def test_push_updates_the_branch_that_was_already_there(tmp_path):
    """It must update the remote's real branch, not create a second one beside it."""
    remote = _bare(tmp_path)
    work = tmp_path / "old"
    work.mkdir()
    _seed_old_repo(remote, work)

    result = push_to_remote(str(remote), message="sync", clean=True)

    assert result["ok"], result.get("detail")
    assert result["branch"] == "main", "must push to the branch the remote already uses"

    branches = subprocess.run(
        ["git", "--git-dir", str(remote), "branch", "--list"], capture_output=True, text=True
    ).stdout.split()
    assert branches == ["main"], f"should not have created a second branch: {branches}"


def test_push_replaces_stale_content_and_drops_deleted_files(tmp_path):
    remote = _bare(tmp_path)
    work = tmp_path / "old"
    work.mkdir()
    _seed_old_repo(remote, work)

    result = push_to_remote(str(remote), message="sync", clean=True)
    tracked = _tree(remote, result["branch"])

    # stale nested copy from an earlier zip upload is gone
    assert not any(p.startswith("uburinzi/") for p in tracked)
    # files we no longer ship are removed
    assert "legacy_notes.txt" not in tracked
    # every current source file is there
    missing = {str(rel) for _, rel in iter_source_files()} - tracked
    assert not missing, f"missing from the remote: {sorted(missing)[:5]}"

    login = subprocess.run(
        ["git", "--git-dir", str(remote), "show", "main:templates/login.html"],
        capture_output=True, text=True,
    ).stdout
    assert "manderajackson99@gmail.com" in login
    assert "founder@uburinzi.rw" not in login
    assert "timbuktoo" not in login


def test_second_push_is_a_no_op(tmp_path):
    remote = _bare(tmp_path)
    push_to_remote(str(remote), message="first")
    again = push_to_remote(str(remote), message="second")

    assert again["ok"]
    assert again["changed"] == 0, "pushing unchanged code must not create an empty commit"


def test_dry_run_does_not_touch_the_remote(tmp_path):
    remote = _bare(tmp_path)
    result = push_to_remote(str(remote), message="peek", dry_run=True)

    assert result["ok"]
    assert result["changed"] > 0
    assert "files" in result
    assert subprocess.run(
        ["git", "--git-dir", str(remote), "rev-parse", "--verify", "main"],
        capture_output=True,
    ).returncode != 0, "a dry run must not push anything"


def test_pushed_tree_never_contains_secrets(tmp_path):
    remote = _bare(tmp_path)
    result = push_to_remote(str(remote), message="check")
    tracked = _tree(remote, result["branch"])

    assert not any(p == ".env" or p.endswith("/.env") for p in tracked)
    assert not any(p.endswith((".db", ".sqlite3", ".pyc")) for p in tracked)


def test_bad_remote_url_is_reported_not_raised(tmp_path):
    result = push_to_remote(str(tmp_path / "does-not-exist.git"), message="nope")
    assert result["ok"] is False
    assert result["error"] == "clone failed"


def _seed_multi_snapshot_repo(remote: Path, workdir: Path):
    """The real-world layout: several nested snapshots from repeated zip uploads."""
    _git("init", "-q", "-b", "main", ".", cwd=workdir)
    for folder, email in (("uburinzi", "founder@uburinzi.rw"),
                          ("workspace-01/uburinzi", "founder@uburinzi.rw"),
                          ("workspace-02/uburinzi", "founder@uburinzi.rw")):
        (workdir / folder / "app").mkdir(parents=True, exist_ok=True)
        (workdir / folder / "app" / "main.py").write_text(f"# {email}\n")
        (workdir / folder / "requirements.txt").write_text("fastapi\n")
    (workdir / "github-upload.md").write_text("stray doc at the root\n")
    _git("add", "-A", cwd=workdir)
    _git("commit", "-qm", "many uploads", cwd=workdir)
    _git("remote", "add", "origin", str(remote), cwd=workdir)
    _git("push", "-q", "-u", "origin", "main", cwd=workdir)


def test_stale_snapshots_are_detected_by_shape_not_by_name(tmp_path):
    from app.package import find_stale_copies

    remote = _bare(tmp_path)
    work = tmp_path / "many"
    work.mkdir()
    _seed_multi_snapshot_repo(remote, work)

    clone = tmp_path / "clone"
    _git("clone", "-b", "main", str(remote), str(clone), cwd=tmp_path)
    assert find_stale_copies(clone) == ["uburinzi", "workspace-01", "workspace-02"]


def test_clean_collapses_every_old_snapshot_into_one_flat_project(tmp_path):
    remote = _bare(tmp_path)
    work = tmp_path / "many"
    work.mkdir()
    _seed_multi_snapshot_repo(remote, work)

    result = push_to_remote(str(remote), message="flatten", clean=True)
    assert result["ok"], result.get("detail")

    tracked = _tree(remote, result["branch"])
    # one canonical project at the root ...
    assert "requirements.txt" in tracked
    assert "app/main.py" in tracked
    assert "vercel.json" in tracked
    # ... and no leftover snapshots
    assert not [p for p in tracked if p.startswith(("uburinzi/", "workspace-"))]
    assert "github-upload.md" not in tracked


def test_without_clean_the_old_snapshots_are_still_removed(tmp_path):
    """Deletions work from the file list alone; --clean only makes the log explicit."""
    remote = _bare(tmp_path)
    work = tmp_path / "many"
    work.mkdir()
    _seed_multi_snapshot_repo(remote, work)

    push_to_remote(str(remote), message="flatten")
    tracked = _tree(remote, "main")
    assert not [p for p in tracked if p.startswith(("uburinzi/", "workspace-"))]
