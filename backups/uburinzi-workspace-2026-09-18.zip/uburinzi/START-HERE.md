# Uburinzi Health

**Chronic patient monitoring between clinic visits — SMS-first, Africa-ready.**

Patients get an ordinary SMS on a 2G phone and answer `1` / `2` / `3`. No smartphone, no app, no data.
Clinics get a live dashboard, a traffic-light alert queue, and escalation that adapts when someone
goes quiet.

---

## 👉 Start with the complete guide

**[docs/UBURINZI-COMPLETE-GUIDE.md](docs/UBURINZI-COMPLETE-GUIDE.md)** — one document covering the
whole project: how it works, where it stands today, the Africa's Talking setup, the Rwanda-specific
reply path, the exact Vercel deployment sequence (including the two mistakes that break it), the
Play Store package, real-patient onboarding, costs, and troubleshooting.

## 👉 Only 5 account steps stand between this and a live site

**[docs/WHAT-YOU-NEED-TO-DO.md](docs/WHAT-YOU-NEED-TO-DO.md)** — GitHub token, Vercel Root
Directory, Neon database, environment variables, redeploy. All of it on websites, none of it in code.

## Quick start (60 seconds)

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m app.cli reset
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Sign in: `manderajackson99@gmail.com` / `uburinzi2026` (admin),
`yahshuamediasite@gmail.com` / `uburinzi2026` (clinician).

## Everything else

| Document | What it covers |
|---|---|
| [UBURINZI-COMPLETE-GUIDE.md](docs/UBURINZI-COMPLETE-GUIDE.md) | **the master guide — start here** |
| [WHAT-YOU-NEED-TO-DO.md](docs/WHAT-YOU-NEED-TO-DO.md) | the 5 account steps to go live |
| [create-live-app.md](docs/create-live-app.md) | creating the Africa's Talking app, credit, sender ID |
| [live-setup.md](docs/live-setup.md) | webhooks, WhatsApp, voice, USSD configuration |
| [deploy-vercel.md](docs/deploy-vercel.md) | Vercel + Postgres + cron, env vars, verification |
| [play-store.md](docs/play-store.md) | Play Store (Trusted Web Activity), store listing copy |
| [github-upload.md](docs/github-upload.md) | regenerating and pushing the GitHub-ready folder |
| [launch-checklist.md](docs/launch-checklist.md) | consent and the first real patients |
| [deploy.md](docs/deploy.md) | ngrok, PaaS and VPS alternatives |
| [demo-script.md](docs/demo-script.md) | the 3-minute recording script |

After any change, put it on GitHub with one command:

```bash
python -m app.cli push --repo https://github.com/YOUR-USER/uburinzi-health.git
```

It updates the branch already in the repo, so a connected Vercel project redeploys on its own.
(`python -m app.cli bundle` refreshes `~/github-upload` if you'd rather run git yourself.)
